import React, { useState } from 'react';
import taskCol from './taskCol';

const ColumnNames = [
    { id: 'in-progress', title: 'In Progress', tasks: [] },
  { id: 'todo', title: 'To Do', tasks: [] },
  { id: 'completed', title: 'Completed', tasks: [] },
];

const TaskManagementBoard = () => {
  const [columns, setColumns] = useState(ColumnNames);

  const addTask = (columnId, task) => {
    setColumns((prev) =>
      prev.map((column) =>
        column.id === columnId
          ? { ...column, tasks: [...column.tasks, task] }
          : column
      )
    );
  };

  return (
    <div className="task-board">
      {columns.map((column) => (
        <taskCol key={column.id} column={column} addTask={addTask} />
      ))}
    </div>
  );
};

export default TaskManagementBoard;

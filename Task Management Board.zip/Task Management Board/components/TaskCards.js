import React from 'react';

const TaskCards = ({ task }) => {
  return (
    <div className="task-card">
      <p>{task.name}</p>
    </div>
  );
};

export default TaskCards;

import React, { useState } from 'react';
import TaskCards from './TaskCards';

const taskCol = ({ column, addTask }) => {
  const [taskName, setTaskName] = useState('');

  const addTask = () => {
    const newTask = { id: Date.now(), name: taskName };
    addTask(column.id, newTask);
    setTaskName('');
  };

  return (
    <div className="task-column">
      <h3>{column.title}</h3>
      <div>
        {column.tasks.map((task) => (
          <TaskCards key={task.id} task={task} />
        ))}
      </div>
      <input
        type="text"
        value={taskName}
        onChange={(e) => setTaskName(e.target.value)}
        placeholder="Add new task"
      />
      <button onClick={addTask}>Add New Task</button>
    </div>
  );
};

export default taskCol;

import TaskManagementBoard from '../components/TaskManagementBoard';

export default function HomePage() {
  return (
    <div>
      <h1>Task Management Board</h1>
      <TaskManagementBoard />
    </div>
  );
}
